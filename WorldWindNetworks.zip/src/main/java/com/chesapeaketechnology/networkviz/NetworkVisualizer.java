package com.chesapeaketechnology.networkviz;

import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.layers.Layer;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.util.WWUtil;
import gov.nasa.worldwindx.examples.ApplicationTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.lang.invoke.MethodHandles;

// My addons
import java.io.File;
import java.io.IOException;
import gov.nasa.worldwindx.examples.GeoJSONLoader;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.Timer;
import javax.swing.JLabel;
import java.awt.event.ActionListener;


/**
 * Creates and manages visuals within a WorldWind based application. Default controls for toggling the visibility of each
 * {@link Layer} and skeleton methods are included to help get started.
 * <p>
 * Additional documentation can be found at WorldWind's open source github - https://nasaworldwind.github.io/WorldWindJava/.
 */
public class NetworkVisualizer extends ApplicationTemplate
{
    private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    private AppFrame appFrame;
    private int queryInterval;
    private JLabel queryIntervalLabel;
    private String url;
    private Timer timer;
    private RenderableLayer fileGeoJSONLayer;
    private RenderableLayer liveGeoJSONLayer;

    /**
     * Configures and opens the WorldWind application that can be used to view GeoJSON data. After this method completes,
     * the {@link #appFrame} will be initialized.
     */
    public void launchApplication()
    {
        queryInterval = 300; // 5 Minute default value for live stream query
        url = null;
        appFrame = start("World Wind JSON Network Viewer", AppFrame.class);

        // Add query timer label to the status bar
        queryIntervalLabel = new JLabel("Query Interval: " + queryInterval + " seconds");
        appFrame.getStatusBar().add(queryIntervalLabel);

        // Reconfigure the size of the World Window to take up the space typically used by the layer panel
        Dimension dimension = new Dimension(1400, 800);
        appFrame.setPreferredSize(dimension);
        appFrame.pack();
        WWUtil.alignComponent(null, appFrame, AVKey.CENTER);
        addMenusToFrame();
    }

    /**
     * Adds menu options that visualize GeoJSON data to the WorldWind application's menubar.
     */
    private void addMenusToFrame()
    {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem openFileMenuItem = makeOpenFileMenu();
        JMenuItem openLinkMenuItem = makeOpenLinkMenu();
        JMenuItem openQueryMenuItem = makeQueryMenu();

        appFrame.setJMenuBar(menuBar);
        menuBar.add(fileMenu);
        fileMenu.add(openFileMenuItem);
        fileMenu.add(openLinkMenuItem);
        fileMenu.add(openQueryMenuItem);
    }

    /**
     * Creates a menu option to allow users to view GeoJSON data on the WorldWind canvas.
     *
     * @return A menu option that can be added to an application's menu bar.
     */
    private JMenuItem makeOpenFileMenu()
    {
        // Start File chooser object that accepts JSONs
        final JFileChooser fileChooser = new JFileChooser();
        fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("JSON File", "json", "json"));

        // Additional options
        File projectRootDirectory = new File(System.getProperty("user.dir")); 
        fileChooser.setCurrentDirectory(projectRootDirectory); // Set the initial directory to the project root
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); // Can only select files
        fileChooser.setMultiSelectionEnabled(false); // Can't select multiple files
        fileChooser.setDialogTitle("Select a JSON file"); // Clearer dialog title so user can know what to pick

        JMenuItem openFileMenuItem = new JMenuItem(new AbstractAction("Open File...")
        {
            public void actionPerformed(ActionEvent actionEvent)
            {
                try
                {
                    // Remove existing fileGeoJSONLayer if it exists
                    if (fileGeoJSONLayer != null)
                        appFrame.getWwd().getModel().getLayers().remove(fileGeoJSONLayer);

                    // Initialize loader to parse JSON and layer to add onto WorldWindow
                    GeoJSONLoader loader = new GeoJSONLoader();
                    fileGeoJSONLayer = new RenderableLayer();
                    fileGeoJSONLayer.setName("GeoJSON File Layer");

                    int status = fileChooser.showOpenDialog(appFrame);
                    if (status == JFileChooser.APPROVE_OPTION)
                    {
                        File jsonFile = fileChooser.getSelectedFile(); // Get selected file
                        
                        // Check if the selected file has a ".json" extension
                        if (!jsonFile.getName().endsWith(".json")) 
                            throw new IOException("Selected file is not a JSON file.");
                        loader.addSourceGeometryToLayer(jsonFile, fileGeoJSONLayer); // Parse JSON and add geometry to the layer
                        appFrame.getWwd().getModel().getLayers().add(fileGeoJSONLayer); // Add layer to the WorldWindow
                        appFrame.getWwd().redraw(); // Redraw to see changes
                    }
                    else
                        throw new IOException("File selection was canceled or no file was chosen."); // If user exits out of selection
                } catch (IOException e) {
                    // Handle IO exceptions (e.g., file not found, file read/write errors)
                    JOptionPane.showMessageDialog(appFrame,
                            e.getMessage(),
                            "File Selection Error", JOptionPane.ERROR_MESSAGE);
                } 
            }
        });
        return openFileMenuItem;
    }
    /**
     * Creates a menu option to allow users to enter a link to a live GeoJSON feed
     *
     * @return A menu option that can be added to an application's menu bar.
     */
    private JMenuItem makeOpenLinkMenu()
    {
        JMenuItem openLinkMenuItem = new JMenuItem(new AbstractAction("Open Link...")
        {
            public void actionPerformed(ActionEvent actionEvent)
            {
                try
                {
                    // Remove existing liveGeoJSONLayer if it exists
                    if (liveGeoJSONLayer != null)
                        appFrame.getWwd().getModel().getLayers().remove(liveGeoJSONLayer);

                    // Initialize loader to parse JSON and layer to add onto WorldWindow
                    GeoJSONLoader loader = new GeoJSONLoader();
                    liveGeoJSONLayer = new RenderableLayer();
                    liveGeoJSONLayer.setName("Live GeoJSON Layer");

                    // Repeatedly prompt user until they exit or give a proper response
                    while (url == null || url.isEmpty() || !url.endsWith(".json")) 
                    {
                        String userInput = JOptionPane.showInputDialog(null, "Enter live JSON Feed URL:");
            
                        // User canceled the input dialog or enters nothing
                        if (userInput == null || userInput.isEmpty()) 
                        {
                            url = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"; // URL is default link
                            break;
                        }
                        // Valid JSON feed URL provided
                        else if (userInput.endsWith(".json")) 
                        {
                            url = userInput; // Update url to user's input
                            break;
                        }
                        else 
                            throw new Exception("Invalid JSON Feed URL The URL must end with '.json'.");
                    }
                    loader.addSourceGeometryToLayer(url, liveGeoJSONLayer); // Parse live JSON and add geometry to the layer
                    appFrame.getWwd().getModel().getLayers().add(liveGeoJSONLayer); // Add layer to the WorldWindow
                    appFrame.getWwd().redraw(); // Redraw to see changes
                    startTimer(); // Start query refresh timer with current interval

                } catch (Exception e){
                    JOptionPane.showMessageDialog(null,
                    "Error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        return openLinkMenuItem;
    }
    /**
     * Creates a menu option to allow users to enter a query timer value
     *
     * @return A menu option that can be added to an application's menu bar.
     */
    private JMenuItem makeQueryMenu()
    {
        JMenuItem openQueryMenu = new JMenuItem(new AbstractAction("Adjust Query Timer...")
        {
            public void actionPerformed(ActionEvent actionEvent)
            {
                try
                {
                    // Create new panel to prompt users for answer
                    JPanel panel = new JPanel();
                    JTextField inputField = new JTextField(10);
                    panel.add(inputField);
                    String[] timeUnits = {"seconds", "minutes"}; // Two options for units
                    JComboBox<String> unitComboBox = new JComboBox<>(timeUnits);
                    panel.add(unitComboBox);

                    // Show the input dialog and capture user input
                    int result = JOptionPane.showConfirmDialog(null, panel, "Enter Query Time Interval",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    // If the user clicked the OK button
                    if (result == JOptionPane.OK_OPTION) 
                    {
                        String userInput = inputField.getText().trim(); // Get the user input value
                        String selectedUnit = (String)unitComboBox.getSelectedItem(); // Get the selected time unit from the combo box
                        
                        // Validate and process the user input
                        if (!userInput.isEmpty()) 
                        {
                            int timeValue = Integer.parseInt(userInput); // Parse user (string) input into an integer

                            // Determine the time interval in seconds based on the selected time unit
                            if(selectedUnit.equals("minutes"))
                                queryInterval = timeValue * 60;
                            else
                                queryInterval = timeValue; // Additional variable for clarity

                            // Catch if user-input is within the valid range (1 second and 5 minutes)
                            if (queryInterval < 1)
                                throw new IllegalArgumentException("Time value cannot be below 1 second");
                            else if(queryInterval > 300)
                                throw new IllegalArgumentException("Time value cannot exceed 5 minutes (300 seconds)");

                            // Query interval is now updated, start the timer again
                            startTimer();
                        } 
                        else
                            throw new IllegalArgumentException("Input field cannot be empty");
                    }

                } catch (NumberFormatException e) {
                    // Handle invalid non-integer input
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer number.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (IllegalArgumentException e) {
                    // Handle input out of range or if empty
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        return openQueryMenu;
    }
    /*
     * Starts the Java Swing timer or stops/starts time again if timer already exists
     */
    private void startTimer() 
    {
        // Stop the existing timer if one is already running
        if (timer != null)
            timer.stop(); 

        // Create new timer, refresh layer with updated link, and redraw
        timer = new Timer(queryInterval * 1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // ActionListener logic to refresh the layer
                RenderableLayer layer = new RenderableLayer();
                layer.setName("Live GeoJSON Layer");
                GeoJSONLoader loader = new GeoJSONLoader();
                loader.addSourceGeometryToLayer(url, layer);
                appFrame.getWwd().getModel().getLayers().add(layer);
                appFrame.getWwd().redraw();

                // Alert user of refresh. Annoying for small refreshes so probably leave this out
                //JOptionPane.showMessageDialog(appFrame,"Data refreshed successfully.","Data Refresh",JOptionPane.INFORMATION_MESSAGE);
            }
        });
        timer.start(); // Start the new timer with the updated interval
        queryIntervalLabel.setText("Query Interval: " + queryInterval + " seconds"); // Update query interval label
    }
    public static void main(String[] args)
    {
        NetworkVisualizer networkVisualizer = new NetworkVisualizer();
        networkVisualizer.launchApplication();
    }
}
